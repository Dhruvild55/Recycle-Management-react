/* eslint-disable no-irregular-whitespace */
const Footer = () => {
  return (
    <div className="footer-section">
      <p>Copyright© 2025 FatHopes Energy (Admin). All Rights Reserved</p>
    </div>
  );
};

export default Footer;
